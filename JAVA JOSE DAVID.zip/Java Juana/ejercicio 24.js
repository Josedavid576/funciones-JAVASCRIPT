//Leer 10 números y obtener su cubo y su cuarta parte.
let totalCubo = 0;
for (let i = 1; i <= 10; i++) {
    let numero = parseFloat(prompt("Ingrese el número " + i));
    let cubo = Math.pow(numero, 3);
    let cuartaParte = numero / 4;
    totalCubo += cubo;
    console.log("Número: " + numero + ", Cubo: " + cubo + ", Cuarta Parte: " + cuartaParte);
}
console.log("Total de cubos: " + totalCubo);
