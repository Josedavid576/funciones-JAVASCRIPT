//Calcular e imprimir el salario básico, el salario neto y cada uno de los porcentajes que tienen
//los empleados en su liquidación de nómina. Tenga en cuenta que recibe un auxilio de
//alimentación del 1% del salario básico y un subsidio de transporte de $45.000. Luego se le
//hacen unas deducciones correspondientes al 1.5%, 28.1% y 0.55% por concepto de salud,
//pensión y aportes parafiscales respectivamente. Luego de calculado el salario neto, se pide
//sacar un 0.05% del salario neto para una donación a una catástrofe.

for (let i = 1, n = +prompt("liquidacionempleado"); i <= n; i++) {
    let b = +prompt("empleado {i} básico:");
    let neto = (b * 1.01 + 45000) - (b * 0.3015);
    console.log("empleado {i} Neto: {neto.toFixed(2)} | Donación: {(neto * 0.0005).toFixed(2)}");
  }