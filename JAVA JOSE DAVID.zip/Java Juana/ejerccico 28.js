//Suponga que se tiene un conjunto de calificaciones de un grupo de 40 alumnos. Realizar un
//algoritmo para calcular la calificación media y la calificación más baja de todo el grupo.
let total = 0;
let calificacionMasBaja = Infinity;
for (let i = 1; i <= 40; i++) {
    let calificacion = parseFloat(prompt("Ingresar calificación" + i));
    total += calificacion;
    if (calificacion < calificacionMasBaja) {
        calificacionMasBaja = calificacion;
    }
}
let promedio = total / 40;
console.log("Calificación media: " + promedio);
console.log("Calificación más baja: " + calificacionMasBaja);