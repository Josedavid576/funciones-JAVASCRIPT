//Leer la temperatura de varios días (en grados centígrados). Convertir ese temperatura a oK
//y oF.
let n = parseInt(prompt("numerodias)"));
let total = 0;
for (let i = 1; i <= n; i++){
    let temperatura = parseFloat(prompt("ingresae temperatura" +i+" en °C"));
    let oK = temperatura + 273.15;
    let oF = (temperatura * 9/5) + 32;
    console.log("dia " + i + " °C: " + temperatura + " °K: " + oK.toFixed(2) + " °F: " + oF.toFixed(2));
}
