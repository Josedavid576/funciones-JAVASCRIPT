//Leer 15 números negativos y convertirlos a positivos e imprimir dichos números.
for (let i = 1; i <= 15; i++) {
    let numero = parseFloat(prompt("Ingrese el número " + i));
    if (numero < 0) {
        numero = -numero;
        console.log("Número convertido a positivo: " + numero);
    }
}