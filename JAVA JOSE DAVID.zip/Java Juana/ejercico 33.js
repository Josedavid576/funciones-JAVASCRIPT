function ejercicio33() {
let suma = 0, menor = Infinity, mayor = -Infinity;
for (let i = 1; i <= 25; i++) {
let pts = +prompt(`Auto ${i} - puntos contaminantes:`);
suma += pts;
if (pts < menor) menor = pts;
if (pts > mayor) mayor = pts;
}
console.log(`Suma de puntos contaminantes: ${suma}`);
console.log(`Menor valor: ${menor}`);
console.log(`Mayor valor: ${mayor}`);