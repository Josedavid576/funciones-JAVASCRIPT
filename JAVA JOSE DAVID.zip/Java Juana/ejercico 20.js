//Leer la fecha de nacimiento de 300 personas. Calcular e imprimir sus edades.
let totaledades =0;
for (let i =1; i <= 300; i++){
    let fecha = prompt("fechanacimiento" +i+" (dd/mm/aaaa)");
    let fechanac = new Date(fecha);
    let hoy = new Date();
    let edad = hoy.getFullYear() - fechanac.getFullYear();
    totaledades += edad;
}
console.log("edad total: " + totaledades);