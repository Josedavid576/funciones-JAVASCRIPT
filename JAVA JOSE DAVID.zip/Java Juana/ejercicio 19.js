//Calcular el peso equivalente en Gramos de 250 frutas que tienen un peso no conocido en
//Kilogramos.

let pesototal = 0;
for (let i = 1; i <= 250; i++){
    let peso = parseFloat(prompt("peso fruta "+i+" en kg"));
    pesototal += peso;
}
console.log("peso total en gramos: " + (pesototal * 1000));