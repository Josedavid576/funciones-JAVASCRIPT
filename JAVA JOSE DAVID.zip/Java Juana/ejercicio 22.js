//Leer la edad de N personas. Calcular e imprimir el número de días que ha vivido.
let n = parseIint(promopt("numeropersonas"));
let totaldias = 0;
for (let i = 1; i <= n; i++){
    let edad = parseInt(prompt("ingrese edad de la persona " + i));
    totaldias += edad * 365;
}
console.log("total de días vividos: " + totaldias);