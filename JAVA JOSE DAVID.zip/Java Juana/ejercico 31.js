//Una persona debe realizar un muestreo con 50 personas para determinar el promedio de
//peso de los niños, jóvenes, adultos y viejos que existen en su zona habitacional. Se
//determinan las categorías con base en la sig., tabla:
function ejercicio31() {
  let cat = [[0,0],[0,0],[0,0],[0,0]]; // [suma, contador] para ninos, jovenes, adultos, viejos
  for (let i = 1; i <= 50; i++) {
    let edad = +prompt(`Persona ${i} - edad:`), peso = +prompt(`Persona ${i} - peso (kg):`);
    let idx = edad <= 12 ? 0 : edad <= 29 ? 1 : edad <= 59 ? 2 : 3;
    cat[idx][0] += peso; cat[idx][1]++;
  }
  let nombres = ["Niños", "Jóvenes", "Adultos", "Viejos"];
  cat.forEach((c, idx) => console.log(`${nombres[idx]}: ${c[1] > 0 ? (c[0] / c[1]).toFixed(2) + " kg" : "sin datos"}`));
}