//Calcular e imprimir la tabla de multiplicar de un número cualquiera. Imprimir el
//multiplicando, el multiplicador y el producto.
function ejercicio29() {
  let num = +prompt("¿De qué número quieres la tabla?"), i = 1;
  while (i <= 10) {
    console.log(`${num} x ${i} = ${num * i}`);
    i++;
  }
}