//Calcular el promedio de un alumno que tiene 7 calificaciones en la materia de Diseño
//Estructurado de Algoritmos
let total = 0;
for (let i = 1; i <= 7; i++) {
    let calificacion = parseFloat(prompt("Ingrese la calificación " + i));
    total += calificacion;
}
let promedio = total / 7;
console.log("El promedio es: " + promedio.toFixed(2));