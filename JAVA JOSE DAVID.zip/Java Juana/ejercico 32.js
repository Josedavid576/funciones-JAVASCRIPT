//Al cerrar un expendio de naranjas, 15 clientes que aún no han pagado recibirán un 15% de
//descuento si compran más de 10 kilos. Determinar cuánto pagara cada cliente y cuanto
//percibirá la tienda por esas compras.
let totalTienda = 0;
for (let i = 1; i <= 15; i++) {
    let kilos = parseFloat(prompt(`Cliente ${i}, ingrese los kilos de naranjas:`));
    let precioPorKilo = parseFloat(prompt(`Cliente ${i}, ingrese el precio por kilo:`));
    let total = kilos * precioPorKilo;
    if (kilos > 10) {
        total *= 0.85; // Aplicar descuento del 15%
    }
    totalTienda += total;
    console.log(`Cliente ${i}: $${total.toFixed(2)}`);
}
console.log(`Total percibido por la tienda: $${totalTienda.toFixed(2)}`);