//En una competencia se inscribieron un numero no conocido de atletas. Cada uno recorre
//tres distancias diferentes en tres competiciones distintas. Calcular e imprimir la distancia
//promedio.

let n = parseInt(prompt("numero de atletas"));
let totalDistancia = 0;
for (let i = 1; i <= n; i++) {
    let distancia1 = parseFloat(prompt("ingrese distancia 1 del atleta " + i));
    totalDistancia += distancia1;
}
console.log("distanciapromedio: " + (totaldistancia / n));
