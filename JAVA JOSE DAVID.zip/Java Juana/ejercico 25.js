//Leer 10 números e imprimir solamente los números positivos
for (let i = 1; i <= 10; i++) {
    let numero = parseFloat(prompt("Ingrese el número " + i));
    if (numero > 0 ) {
        console.log("Número positivo: " + numero);
    }
}