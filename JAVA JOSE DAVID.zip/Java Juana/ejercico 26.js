//Leer 20 números e imprimir cuantos son positivos, cuantos negativos y cuantos son 0.
let positivos = 0;
let negativos = 0;
let ceros = 0;

for (let i = 1; i <= 20; i++) {
    let numero = parseFloat(prompt("Ingrese el número " + i));
    if (numero > 0) {
        positivos++;
    } else if (numero < 0) {
        negativos++;
    } else {
        ceros++;
    }
}

console.log("Positivos: " + positivos);
console.log("Negativos: " + negativos);
console.log("Ceros: " + ceros);