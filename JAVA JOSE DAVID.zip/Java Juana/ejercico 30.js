//Simular el comportamiento de un reloj digital, imprimiendo la hora, minutos y segundos de
//un día desde las 0:00:00 horas hasta las 23:59:59 horas
for (let hora = 0; hora < 24; hora++) 
    for (let minuto = 0; minuto < 60; minuto++) {
        for (let segundo = 0; segundo < 60; segundo++) {
            console.log(`${hora.toString().padStart(2, '0')}:${minuto.toString().padStart(2, '0')}:${segundo.toString().padStart(2, '0')}`);
        }
    }