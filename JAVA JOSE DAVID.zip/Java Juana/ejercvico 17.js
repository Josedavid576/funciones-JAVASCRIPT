//Calcular el salario neto de N empleados sabiendo que se les hace una retención del 3% para
//pensión y 5% para salud. Se debe leer el valor de cada hora y el número de horas trabajadas
//por los empleados.
for (let i = 1, n = +prompt("Empleados?"); i <= n; i++) {
    let bruto = +prompt(`Emp ${i} valor hora:`) * +prompt(`Horas:`);
    console.log(`Emp ${i} neto: $${(bruto * 0.92).toFixed(2)}`);
  }
